package ir.game.haftkhabisvip.audio

import android.media.AudioManager
import android.media.ToneGenerator

object SoundEffects {
    private val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 85)

    fun playCardThrow() {
        toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 60)
    }

    fun playDrawCard() {
        toneGen.startTone(ToneGenerator.TONE_PROP_ACK, 90)
    }

    fun playError() {
        toneGen.startTone(ToneGenerator.TONE_PROP_NACK, 200)
    }

    fun playTurnNotification() {
        toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 150)
    }

    fun playRoundWin() {
        toneGen.startTone(ToneGenerator.TONE_CDMA_MED_L, 400)
    }

    fun playShuffle() {
        toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
    }
}
