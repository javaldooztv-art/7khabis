package ir.game.haftkhabisvip.network

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import ir.game.haftkhabisvip.model.ClientIntent
import ir.game.haftkhabisvip.model.GameState
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class P2PNetworkManager(
    context: Context,
    private val onPeerConnected: (endpointId: String, name: String) -> Unit,
    private val onPeerDisconnected: (endpointId: String) -> Unit,
    private val onGameStateReceived: (GameState) -> Unit,
    private val onClientIntentReceived: (endpointId: String, ClientIntent) -> Unit
) {
    private val connectionsClient = Nearby.getConnectionsClient(context)
    private val serviceId = "ir.game.haftkhabisvip.WIFI_DIRECT_SERVICE"
    private val connectedEndpoints = mutableMapOf<String, String>()
    private var pendingNames = mutableMapOf<String, String>()

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val text = String(bytes, Charsets.UTF_8)
            
            if (text.startsWith("STATE:")) {
                val stateJson = text.removePrefix("STATE:")
                val state = Json.decodeFromString<GameState>(stateJson)
                onGameStateReceived(state)
            } else if (text.startsWith("INTENT:")) {
                val intentJson = text.removePrefix("INTENT:")
                val intent = Json.decodeFromString<ClientIntent>(intentJson)
                onClientIntentReceived(endpointId, intent)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            pendingNames[endpointId] = info.endpointName
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                val name = pendingNames[endpointId] ?: "بازیکن"
                connectedEndpoints[endpointId] = name
                onPeerConnected(endpointId, name)
            }
        }

        override fun onDisconnected(endpointId: String) {
            connectedEndpoints.remove(endpointId)
            onPeerDisconnected(endpointId)
        }
    }

    fun startHosting(hostName: String) {
        val options = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_STAR)
            .build()
        connectionsClient.startAdvertising(
            hostName,
            serviceId,
            connectionLifecycleCallback,
            options
        )
    }

    fun startDiscovery(clientName: String, onHostFound: (endpointId: String, hostName: String) -> Unit) {
        val options = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_STAR)
            .build()
        connectionsClient.startDiscovery(
            serviceId,
            object : EndpointDiscoveryCallback() {
                override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
                    onHostFound(endpointId, info.endpointName)
                }
                override fun onEndpointLost(endpointId: String) {}
            },
            options
        )
    }

    fun connectToHost(clientName: String, hostEndpointId: String) {
        connectionsClient.requestConnection(clientName, hostEndpointId, connectionLifecycleCallback)
    }

    fun broadcastGameState(state: GameState) {
        if (connectedEndpoints.isEmpty()) return
        val json = "STATE:" + Json.encodeToString(state)
        val payload = Payload.fromBytes(json.toByteArray(Charsets.UTF_8))
        connectionsClient.sendPayload(connectedEndpoints.keys.toList(), payload)
    }

    fun sendIntentToHost(hostEndpointId: String, intent: ClientIntent) {
        val json = "INTENT:" + Json.encodeToString(intent)
        val payload = Payload.fromBytes(json.toByteArray(Charsets.UTF_8))
        connectionsClient.sendPayload(hostEndpointId, payload)
    }

    fun stopAll() {
        connectionsClient.stopAdvertising()
        connectionsClient.stopDiscovery()
        connectionsClient.stopAllEndpoints()
    }
}
