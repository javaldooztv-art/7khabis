package ir.game.haftkhabisvip.engine

import ir.game.haftkhabisvip.model.*
import kotlin.random.Random

class GameEngine(
    private val initialPlayers: List<Pair<String, String>>,
    private val maxRounds: Int
) {
    private var drawPile = mutableListOf<Card>()
    private var discardPile = mutableListOf<Card>()
    
    var state = GameState(
        players = initialPlayers.map { Player(id = it.first, name = it.second) },
        totalRounds = maxRounds,
        hakemIndex = Random.nextInt(initialPlayers.size)
    )
        private set

    fun startNewRound(winnerFromLastRoundIndex: Int? = null) {
        val hakem = winnerFromLastRoundIndex ?: state.hakemIndex
        val numDecks = if (state.players.size <= 4) 1 else 2
        
        drawPile.clear()
        discardPile.clear()
        
        repeat(numDecks) {
            for (suit in listOf(Suit.HEARTS, Suit.DIAMONDS, Suit.CLUBS, Suit.SPADES)) {
                for (rank in Rank.values().filter { it != Rank.JOKER }) {
                    drawPile.add(Card(suit = suit, rank = rank))
                }
            }
            drawPile.add(Card(suit = Suit.JOKER, rank = Rank.JOKER))
            drawPile.add(Card(suit = Suit.JOKER, rank = Rank.JOKER))
        }
        drawPile.shuffle()

        val updatedPlayers = state.players.map { player ->
            val hand = (1..7).map { drawFromBank() }
            player.copy(hand = hand, saidTakKard = false)
        }

        var firstCard = drawFromBank()
        while (firstCard.rank == Rank.JOKER || firstCard.rank == Rank.SEVEN || firstCard.rank == Rank.JACK) {
            drawPile.add(0, firstCard)
            drawPile.shuffle()
            firstCard = drawFromBank()
        }
        discardPile.add(firstCard)

        state = state.copy(
            players = updatedPlayers,
            deckCount = drawPile.size,
            topCard = firstCard,
            activeSuit = firstCard.suit,
            currentTurnIndex = hakem,
            hakemIndex = hakem,
            direction = -1,
            sevenChainPenalty = 0,
            sevenChainInitiatorId = null,
            pendingAction = PendingActionType.NONE,
            hasDrawnThisTurn = false,
            isRoundOver = false,
            statusMessage = "دست ${state.currentRound} شروع شد! نوبت ${updatedPlayers[hakem].name}"
        )
    }

    private fun drawFromBank(): Card {
        if (drawPile.isEmpty()) {
            if (discardPile.size > 1) {
                val top = discardPile.removeLast()
                drawPile.addAll(discardPile)
                discardPile.clear()
                discardPile.add(top)
                drawPile.shuffle()
            } else {
                return Card(suit = Suit.HEARTS, rank = Rank.TWO)
            }
        }
        return drawPile.removeLast()
    }

    fun canPlayCard(card: Card): Boolean {
        val top = state.topCard ?: return false
        val currentSuit = state.activeSuit ?: top.suit

        if (state.sevenChainPenalty > 0) {
            return card.rank == Rank.SEVEN || (card.rank == Rank.KING && card.suit == top.suit)
        }

        if (state.pendingAction == PendingActionType.EIGHT_STREAK) {
            return card.rank == Rank.EIGHT || card.rank == Rank.JACK || card.suit == top.suit
        }

        if (state.pendingAction != PendingActionType.NONE) return false

        if (card.rank == Rank.JACK || card.rank == Rank.JOKER) return true
        return card.suit == currentSuit || card.rank == top.rank
    }

    fun processIntent(playerId: String, intent: ClientIntent): Boolean {
        if (state.isRoundOver || state.isGameOver) return false
        val playerIdx = state.players.indexOfFirst { it.id == playerId }
        if (playerIdx == -1) return false

        if (intent is ClientIntent.DeclareTakKard) {
            val p = state.players[playerIdx]
            if (p.hand.size <= 2) {
                updatePlayer(playerIdx) { it.copy(saidTakKard = true) }
                state = state.copy(statusMessage = "${p.name} اعلام کرد: تک کارت!")
                return true
            }
            return false
        }

        if (playerIdx != state.currentTurnIndex) return false

        return when (intent) {
            is ClientIntent.PlayCard -> handlePlayCard(playerIdx, intent.cardId)
            is ClientIntent.DrawCard -> handleDrawCard(playerIdx)
            is ClientIntent.SelectSuit -> handleSelectSuit(playerIdx, intent.suit)
            is ClientIntent.GiveCardToPlayer -> handleGiveCard(playerIdx, intent.cardId, intent.targetPlayerId)
            is ClientIntent.PassEightBonus -> {
                if (state.pendingAction == PendingActionType.EIGHT_STREAK) {
                    advanceTurn(steps = 1)
                    true
                } else false
            }
            else -> false
        }
    }

    private fun handlePlayCard(playerIdx: Int, cardId: String): Boolean {
        val player = state.players[playerIdx]
        val card = player.hand.find { it.id == cardId } ?: return false
        if (!canPlayCard(card)) return false

        val newHand = player.hand.filterNot { it.id == cardId }
        discardPile.add(card)
        updatePlayer(playerIdx) { it.copy(hand = newHand, saidTakKard = if (newHand.size == 1) it.saidTakKard else false) }

        state = state.copy(
            topCard = card,
            activeSuit = if (card.rank == Rank.JOKER) state.activeSuit else card.suit,
            deckCount = drawPile.size,
            pendingAction = PendingActionType.NONE
        )

        if (newHand.isEmpty()) {
            finishRound(winnerIdx = playerIdx, lastPlayedCard = card)
            return true
        }

        when (card.rank) {
            Rank.SEVEN -> {
                val initiator = state.sevenChainInitiatorId ?: player.id
                val newPenalty = state.sevenChainPenalty + 2
                state = state.copy(
                    sevenChainPenalty = newPenalty,
                    sevenChainInitiatorId = initiator,
                    statusMessage = "${player.name} کارت ۷ انداخت! جریمه فعلی: $newPenalty کارت"
                )
                advanceTurn(1)
            }
            Rank.KING -> {
                if (state.sevenChainPenalty > 0) {
                    val initiatorIdx = state.players.indexOfFirst { it.id == state.sevenChainInitiatorId }
                    val penaltyCount = state.sevenChainPenalty
                    if (initiatorIdx != -1) {
                        val penaltyCards = (1..penaltyCount).map { drawFromBank() }
                        updatePlayer(initiatorIdx) { it.copy(hand = it.hand + penaltyCards) }
                    }
                    val initiatorName = state.players.getOrNull(initiatorIdx)?.name ?: "شروع‌کننده"
                    state = state.copy(
                        sevenChainPenalty = 0,
                        sevenChainInitiatorId = null,
                        deckCount = drawPile.size,
                        statusMessage = "دفاع با شاه! $penaltyCount کارت جریمه به $initiatorName برگشت!"
                    )
                }
                advanceTurn(1)
            }
            Rank.JACK -> {
                state = state.copy(
                    pendingAction = PendingActionType.CHOOSE_SUIT,
                    statusMessage = "${player.name} سرباز انداخت. در حال انتخاب خال..."
                )
            }
            Rank.JOKER -> {
                state.players.forEachIndexed { idx, _ ->
                    if (idx != playerIdx) {
                        val penalty = drawFromBank()
                        updatePlayer(idx) { it.copy(hand = it.hand + penalty) }
                    }
                }
                state = state.copy(
                    deckCount = drawPile.size,
                    statusMessage = "${player.name} جوکر انداخت! همه ۱ کارت جریمه گرفتند."
                )
                advanceTurn(1)
            }
            Rank.TWO -> {
                state = state.copy(
                    pendingAction = PendingActionType.GIVE_PENALTY_CARD,
                    statusMessage = "${player.name} کارت ۲ انداخت. باید یک کارت به یک نفر بدهد."
                )
            }
            Rank.EIGHT -> {
                state = state.copy(
                    pendingAction = PendingActionType.EIGHT_STREAK,
                    statusMessage = "${player.name} کارت ۸ انداخت. می‌تواند ۸ دیگر یا جایزه بیندازد."
                )
            }
            Rank.TEN -> {
                val newDir = state.direction * -1
                state = state.copy(
                    direction = newDir,
                    statusMessage = "جهت بازی برعکس شد!"
                )
                advanceTurn(1)
            }
            Rank.ACE -> {
                state = state.copy(statusMessage = "${player.name} تک انداخت! نفر بعدی بلوک شد.")
                advanceTurn(2)
            }
            else -> {
                advanceTurn(1)
            }
        }
        return true
    }

    private fun handleDrawCard(playerIdx: Int): Boolean {
        val player = state.players[playerIdx]

        if (state.sevenChainPenalty > 0) {
            val penaltyCount = state.sevenChainPenalty
            val penaltyCards = (1..penaltyCount).map { drawFromBank() }
            updatePlayer(playerIdx) { it.copy(hand = it.hand + penaltyCards) }
            state = state.copy(
                sevenChainPenalty = 0,
                sevenChainInitiatorId = null,
                deckCount = drawPile.size,
                statusMessage = "${player.name} تعداد $penaltyCount کارت جریمه هفت را برداشت."
            )
            advanceTurn(1)
            return true
        }

        if (state.pendingAction != PendingActionType.NONE) return false
        if (state.hasDrawnThisTurn) {
            advanceTurn(1)
            return true
        }

        val drawn = drawFromBank()
        updatePlayer(playerIdx) { it.copy(hand = it.hand + drawn) }
        state = state.copy(
            deckCount = drawPile.size,
            hasDrawnThisTurn = true,
            statusMessage = "${player.name} یک کارت از بانک برداشت."
        )

        if (!canPlayCard(drawn)) {
            advanceTurn(1)
        }
        return true
    }

    private fun handleSelectSuit(playerIdx: Int, suit: Suit): Boolean {
        if (state.pendingAction != PendingActionType.CHOOSE_SUIT) return false
        if (suit == Suit.JOKER) return false

        state = state.copy(
            activeSuit = suit,
            pendingAction = PendingActionType.NONE,
            statusMessage = "خال جدید اعلام شد: ${suit.title} ${suit.symbol}"
        )
        advanceTurn(1)
        return true
    }

    private fun handleGiveCard(playerIdx: Int, cardId: String, targetPlayerId: String): Boolean {
        if (state.pendingAction != PendingActionType.GIVE_PENALTY_CARD) return false
        val giver = state.players[playerIdx]
        val targetIdx = state.players.indexOfFirst { it.id == targetPlayerId }
        if (targetIdx == -1 || targetIdx == playerIdx) return false

        val cardToGive = giver.hand.find { it.id == cardId } ?: return false
        val newGiverHand = giver.hand.filterNot { it.id == cardId }

        updatePlayer(playerIdx) { it.copy(hand = newGiverHand) }
        updatePlayer(targetIdx) { it.copy(hand = it.hand + cardToGive) }

        state = state.copy(
            pendingAction = PendingActionType.NONE,
            statusMessage = "${giver.name} یک کارت جریمه به ${state.players[targetIdx].name} داد."
        )

        if (newGiverHand.isEmpty()) {
            finishRound(winnerIdx = playerIdx, lastPlayedCard = state.topCard!!)
        } else {
            advanceTurn(1)
        }
        return true
    }

    private fun advanceTurn(steps: Int) {
        val count = state.players.size
        var nextIdx = (state.currentTurnIndex + (steps * state.direction)) % count
        if (nextIdx < 0) nextIdx += count

        state = state.copy(
            currentTurnIndex = nextIdx,
            pendingAction = PendingActionType.NONE,
            hasDrawnThisTurn = false,
            statusMessage = "${state.statusMessage} | نوبت ${state.players[nextIdx].name}"
        )
    }

    private fun finishRound(winnerIdx: Int, lastPlayedCard: Card) {
        val endedWithJack = lastPlayedCard.rank == Rank.JACK
        val endedWithSeven = lastPlayedCard.rank == Rank.SEVEN
        val multiplier = if (endedWithJack) 2 else 1

        val scoredPlayers = state.players.mapIndexed { idx, player ->
            if (idx == winnerIdx) {
                val winnerRoundScore = if (endedWithSeven) -70 else 0
                player.copy(
                    lastRoundScore = winnerRoundScore,
                    totalScore = player.totalScore + winnerRoundScore
                )
            } else {
                val finalHand = mutableListOf<Card>()
                for (c in player.hand) {
                    if (c.rank == Rank.SEVEN) {
                        finalHand.add(drawFromBank())
                        finalHand.add(drawFromBank())
                    } else {
                        finalHand.add(c)
                    }
                }
                val rawPoints = finalHand.sumOf { it.rank.pointValue }
                val finalRoundScore = rawPoints * multiplier
                player.copy(
                    hand = finalHand,
                    lastRoundScore = finalRoundScore,
                    totalScore = player.totalScore + finalRoundScore
                )
            }
        }

        val isFinalRound = state.currentRound >= state.totalRounds
        val winnerName = scoredPlayers[winnerIdx].name

        state = state.copy(
            players = scoredPlayers,
            isRoundOver = true,
            isGameOver = isFinalRound,
            hakemIndex = winnerIdx,
            statusMessage = if (isFinalRound) "پایان کل بازی! برنده این دست: $winnerName" 
                            else "پایان دست ${state.currentRound}! برنده: $winnerName"
        )
    }

    fun proceedToNextRound() {
        if (!state.isRoundOver || state.isGameOver) return
        state = state.copy(currentRound = state.currentRound + 1)
        startNewRound(winnerFromLastRoundIndex = state.hakemIndex)
    }

    private fun updatePlayer(index: Int, transform: (Player) -> Player) {
        val mutable = state.players.toMutableList()
        mutable[index] = transform(mutable[index])
        state = state.copy(players = mutable)
    }
}
