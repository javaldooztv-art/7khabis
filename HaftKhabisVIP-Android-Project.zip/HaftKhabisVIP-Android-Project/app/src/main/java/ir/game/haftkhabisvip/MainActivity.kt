package ir.game.haftkhabisvip

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.game.haftkhabisvip.audio.SoundEffects
import ir.game.haftkhabisvip.engine.GameEngine
import ir.game.haftkhabisvip.model.*
import ir.game.haftkhabisvip.network.P2PNetworkManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                HaftKhabisApp(this)
            }
        }
    }
}

@Composable
fun HaftKhabisApp(activity: ComponentActivity) {
    var playerName by remember { mutableStateOf("بازیکن ۱") }
    var roundsInput by remember { mutableStateOf("5") }
    var isHost by remember { mutableStateOf(false) }
    var inGame by remember { mutableStateOf(false) }
    var hostEndpointId by remember { mutableStateOf<String?>(null) }

    val lobbyPlayers = remember { mutableStateListOf<Pair<String, String>>() }
    val discoveredHosts = remember { mutableStateMapOf<String, String>() }
    var gameState by remember { mutableStateOf<GameState?>(null) }
    var engine by remember { mutableStateOf<GameEngine?>(null) }
    var showScoreboard by remember { mutableStateOf(false) }

    val networkManager = remember {
        P2PNetworkManager(
            context = activity,
            onPeerConnected = { endpointId, name ->
                if (isHost) {
                    if (lobbyPlayers.size < 7) {
                        lobbyPlayers.add(endpointId to name)
                    }
                } else {
                    hostEndpointId = endpointId
                    inGame = true
                }
            },
            onPeerDisconnected = { endpointId ->
                lobbyPlayers.removeAll { it.first == endpointId }
            },
            onGameStateReceived = { newState ->
                val oldTurn = gameState?.currentTurnIndex
                gameState = newState
                inGame = true
                if (newState.isRoundOver) SoundEffects.playRoundWin()
                else if (oldTurn != newState.currentTurnIndex) SoundEffects.playTurnNotification()
            },
            onClientIntentReceived = { senderEndpointId, intent ->
                engine?.let { eng ->
                    val ok = eng.processIntent(senderEndpointId, intent)
                    if (ok) {
                        SoundEffects.playCardThrow()
                        gameState = eng.state
                    }
                }
            }
        )
    }

    LaunchedEffect(gameState) {
        if (isHost && gameState != null) {
            networkManager.broadcastGameState(gameState!!)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    LaunchedEffect(Unit) {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    if (!inGame || gameState == null) {
        LobbyScreen(
            playerName = playerName,
            onNameChange = { playerName = it },
            roundsInput = roundsInput,
            onRoundsChange = { roundsInput = it },
            lobbyPlayers = lobbyPlayers,
            discoveredHosts = discoveredHosts,
            onStartHost = {
                isHost = true
                lobbyPlayers.clear()
                lobbyPlayers.add("HOST" to playerName)
                networkManager.startHosting(playerName)
            },
            onStartDiscovery = {
                isHost = false
                networkManager.startDiscovery(playerName) { id, hName ->
                    discoveredHosts[id] = hName
                }
            },
            onConnectToHost = { hostId ->
                networkManager.connectToHost(playerName, hostId)
            },
            onStartGame = {
                if (lobbyPlayers.size in 2..7) {
                    val totalRounds = (roundsInput.toIntOrNull() ?: 5).coerceIn(1, 50)
                    val newEngine = GameEngine(lobbyPlayers.toList(), totalRounds)
                    SoundEffects.playShuffle()
                    newEngine.startNewRound()
                    engine = newEngine
                    gameState = newEngine.state
                    inGame = true
                    networkManager.broadcastGameState(newEngine.state)
                }
            }
        )
    } else {
        val state = gameState!!
        val myPlayer = if (isHost) {
            state.players.find { it.id == "HOST" }
        } else {
            state.players.find { it.name == playerName }
        } ?: state.players.first()

        val sendAction: (ClientIntent) -> Unit = { intent ->
            if (isHost) {
                val ok = engine?.processIntent("HOST", intent) ?: false
                if (ok) {
                    SoundEffects.playCardThrow()
                    gameState = engine?.state
                } else {
                    SoundEffects.playError()
                }
            } else {
                hostEndpointId?.let { hId ->
                    networkManager.sendIntentToHost(hId, intent)
                }
            }
        }

        GameTableScreen(
            state = state,
            myPlayer = myPlayer,
            isHost = isHost,
            onSendIntent = sendAction,
            onShowScores = { showScoreboard = true },
            onNextRound = {
                if (isHost) {
                    SoundEffects.playShuffle()
                    engine?.proceedToNextRound()
                    gameState = engine?.state
                }
            }
        )

        if (showScoreboard || state.isRoundOver) {
            ScoreboardDialog(
                state = state,
                isHost = isHost,
                onDismiss = { showScoreboard = false },
                onNextRound = {
                    showScoreboard = false
                    if (isHost) {
                        SoundEffects.playShuffle()
                        engine?.proceedToNextRound()
                        gameState = engine?.state
                    }
                }
            )
        }
    }
}

@Composable
fun LobbyScreen(
    playerName: String,
    onNameChange: (String) -> Unit,
    roundsInput: String,
    onRoundsChange: (String) -> Unit,
    lobbyPlayers: List<Pair<String, String>>,
    discoveredHosts: Map<String, String>,
    onStartHost: () -> Unit,
    onStartDiscovery: () -> Unit,
    onConnectToHost: (String) -> Unit,
    onStartGame: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A2E1D))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("هفت خبیث VIP", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD700))
        Text("اتصال آفلاین مستقیم (Wi-Fi Direct) | ۲ تا ۷ نفر", color = Color.White.copy(alpha = 0.8f))

        OutlinedTextField(
            value = playerName,
            onValueChange = onNameChange,
            label = { Text("نام شما در بازی", color = Color.White) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = roundsInput,
            onValueChange = onRoundsChange,
            label = { Text("تعداد دست‌های بازی (۱ تا ۵۰)", color = Color.White) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = onStartHost,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD4AF37)),
                modifier = Modifier.weight(1f)
            ) {
                Text("ساخت میز (میزبان)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onStartDiscovery,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                modifier = Modifier.weight(1f)
            ) {
                Text("جستجوی میز", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        if (lobbyPlayers.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF12472E))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("بازیکنان متصل (${lobbyPlayers.size}/7):", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
                    lobbyPlayers.forEachIndexed { idx, pair ->
                        Text("${idx + 1}. ${pair.second}", color = Color.White, modifier = Modifier.padding(top = 4.dp))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartGame,
                        enabled = lobbyPlayers.size >= 2,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047))
                    ) {
                        Text("شروع بازی (${lobbyPlayers.size} نفر)")
                    }
                }
            }
        }

        if (discoveredHosts.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF12472E))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("میزهای پیدا شده (برای اتصال ضربه بزنید):", color = Color(0xFFFFD700))
                    discoveredHosts.forEach { (id, name) ->
                        Button(
                            onClick = { onConnectToHost(id) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text("اتصال به میزِ $name")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameTableScreen(
    state: GameState,
    myPlayer: Player,
    isHost: Boolean,
    onSendIntent: (ClientIntent) -> Unit,
    onShowScores: () -> Unit,
    onNextRound: () -> Unit
) {
    val isMyTurn = state.players.getOrNull(state.currentTurnIndex)?.id == myPlayer.id
    val directionSymbol = if (state.direction == -1) "↺ (خلاف عقربه)" else "↻ (موافق عقربه)"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1B5E20), Color(0xFF072610))
                )
            )
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "دست ${state.currentRound} از ${state.totalRounds} | جهت: $directionSymbol",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    TextButton(onClick = onShowScores) {
                        Text("📊 جدول امتیازات", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
                    }
                }

                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.players.filter { it.id != myPlayer.id }) { opponent ->
                        val isOpponentTurn = state.players[state.currentTurnIndex].id == opponent.id
                        OpponentBadge(opponent = opponent, isTurn = isOpponentTurn)
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = state.statusMessage,
                    color = Color(0xFFFFE082),
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                if (state.sevenChainPenalty > 0) {
                    Surface(
                        color = Color(0xFFB71C1C),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "🔥 زنجیره هفت فعال: ${state.sevenChainPenalty} کارت جریمه! (دفاع با شاه ${state.topCard?.suit?.symbol} یا ۷ جدید)",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(32.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CardBackView(
                            countLabel = "${state.deckCount}",
                            onClick = {
                                SoundEffects.playDrawCard()
                                onSendIntent(ClientIntent.DrawCard)
                            }
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("بانک کارت", color = Color.White, fontSize = 12.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        state.topCard?.let { top ->
                            PlayingCardView(card = top, onClick = {})
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "خال حکم فعلی: ${state.activeSuit?.symbol ?: ""} ${state.activeSuit?.title ?: ""}",
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                if (isMyTurn && state.pendingAction == PendingActionType.EIGHT_STREAK) {
                    Button(
                        onClick = { onSendIntent(ClientIntent.PassEightBonus) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8F00)),
                        modifier = Modifier.padding(top = 12.dp)
                    ) {
                        Text("پایان نوبت ۸ (بدون انداختن جایزه)")
                    }
                }
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isMyTurn) "🟢 نوبت شماست!" else "⏳ منتظر نوبت...",
                        color = if (isMyTurn) Color(0xFF69F0AE) else Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )

                    Button(
                        onClick = { onSendIntent(ClientIntent.DeclareTakKard) },
                        enabled = myPlayer.hand.size <= 2 && !myPlayer.saidTakKard,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                    ) {
                        Text("📢 اعلام تک کارت!")
                    }
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy((-18).dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    items(myPlayer.hand) { card ->
                        PlayingCardView(
                            card = card,
                            onClick = {
                                onSendIntent(ClientIntent.PlayCard(card.id))
                            }
                        )
                    }
                }
            }
        }

        if (isMyTurn && state.pendingAction == PendingActionType.CHOOSE_SUIT) {
            SuitSelectionDialog(
                onSelectSuit = { chosenSuit ->
                    onSendIntent(ClientIntent.SelectSuit(chosenSuit))
                }
            )
        }

        if (isMyTurn && state.pendingAction == PendingActionType.GIVE_PENALTY_CARD) {
            GiveCardPenaltyDialog(
                myHand = myPlayer.hand,
                otherPlayers = state.players.filter { it.id != myPlayer.id },
                onConfirm = { cardId, targetPlayerId ->
                    onSendIntent(ClientIntent.GiveCardToPlayer(cardId, targetPlayerId))
                }
            )
        }
    }
}

@Composable
fun PlayingCardView(card: Card, onClick: () -> Unit) {
    val cardColor = if (card.suit.isRed) Color(0xFFC62828) else Color(0xFF212121)

    Surface(
        modifier = Modifier
            .width(88.dp)
            .height(130.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFFAFAFA),
        border = BorderStroke(1.5.dp, Color(0xFFBDBDBD)),
        shadowElevation = 8.dp
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            Column(
                modifier = Modifier.align(Alignment.TopStart),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (card.rank == Rank.JOKER) "JKR" else card.rank.label,
                    color = cardColor,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
                Text(text = card.suit.symbol, color = cardColor, fontSize = 14.sp)
            }

            Text(
                text = card.suit.symbol,
                color = cardColor,
                fontSize = 36.sp,
                modifier = Modifier.align(Alignment.Center)
            )

            Column(
                modifier = Modifier.align(Alignment.BottomEnd),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = card.suit.symbol, color = cardColor, fontSize = 14.sp)
                Text(
                    text = if (card.rank == Rank.JOKER) "JKR" else card.rank.label,
                    color = cardColor,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun CardBackView(countLabel: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .width(88.dp)
            .height(130.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1A237E),
        border = BorderStroke(2.dp, Color(0xFFFFD700)),
        shadowElevation = 8.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF283593), Color(0xFF0D47A1))
                    ),
                    shape = RoundedCornerShape(8.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("♠ ♥", color = Color(0xFFFFD700).copy(alpha = 0.6f), fontSize = 14.sp)
                Text(
                    text = countLabel,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Text("♣ ♦", color = Color(0xFFFFD700).copy(alpha = 0.6f), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun OpponentBadge(opponent: Player, isTurn: Boolean) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isTurn) Color(0xFF2E7D32) else Color(0xFF0D3B22),
        border = BorderStroke(if (isTurn) 2.dp else 1.dp, if (isTurn) Color(0xFFFFD700) else Color.Gray)
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier.width(28.dp).height(42.dp),
                shape = RoundedCornerShape(4.dp),
                color = Color(0xFF1A237E),
                border = BorderStroke(1.dp, Color(0xFFFFD700))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("${opponent.hand.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            Column {
                Text(opponent.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("امتیاز: ${opponent.totalScore}", color = Color.LightGray, fontSize = 11.sp)
                if (opponent.saidTakKard || opponent.hand.size == 1) {
                    Text("⚠️ تک کارت!", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SuitSelectionDialog(onSelectSuit: (Suit) -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("انتخاب خال جدید (حکم سرباز)", fontWeight = FontWeight.Bold) },
        text = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(Suit.HEARTS, Suit.DIAMONDS, Suit.CLUBS, Suit.SPADES).forEach { suit ->
                    Surface(
                        modifier = Modifier
                            .size(64.dp)
                            .clickable { onSelectSuit(suit) },
                        shape = CircleShape,
                        color = Color(0xFFEEEEEE),
                        border = BorderStroke(1.dp, Color.Gray)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                suit.symbol,
                                fontSize = 28.sp,
                                color = if (suit.isRed) Color.Red else Color.Black
                            )
                            Text(suit.title, fontSize = 11.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun GiveCardPenaltyDialog(
    myHand: List<Card>,
    otherPlayers: List<Player>,
    onConfirm: (cardId: String, targetPlayerId: String) -> Unit
) {
    var selectedCardId by remember { mutableStateOf(myHand.firstOrNull()?.id ?: "") }
    var selectedPlayerId by remember { mutableStateOf(otherPlayers.firstOrNull()?.id ?: "") }

    AlertDialog(
        onDismissRequest = {},
        title = { Text("جریمه کارت ۲: یک کارت به یک بازیکن بدهید", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("۱. انتخاب کارت از دست شما:")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(myHand) { c ->
                        FilterChip(
                            selected = selectedCardId == c.id,
                            onClick = { selectedCardId = c.id },
                            label = { Text("${c.rank.label}${c.suit.symbol}") }
                        )
                    }
                }
                Text("۲. انتخاب بازیکن هدف:")
                otherPlayers.forEach { p ->
                    FilterChip(
                        selected = selectedPlayerId == p.id,
                        onClick = { selectedPlayerId = p.id },
                        label = { Text("${p.name} (${p.hand.size} کارت)") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedCardId.isNotEmpty() && selectedPlayerId.isNotEmpty()) {
                        onConfirm(selectedCardId, selectedPlayerId)
                    }
                }
            ) {
                Text("ارسال کارت جریمه")
            }
        }
    )
}

@Composable
fun ScoreboardDialog(
    state: GameState,
    isHost: Boolean,
    onDismiss: () -> Unit,
    onNextRound: () -> Unit
) {
    val sortedPlayers = state.players.sortedBy { it.totalScore }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (state.isGameOver) "🏆 نتیجه نهایی بازی (کمترین امتیاز برنده است)"
                else "📊 جدول امتیازات (دست ${state.currentRound} از ${state.totalRounds})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                sortedPlayers.forEachIndexed { idx, p ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${idx + 1}. ${p.name}", fontWeight = FontWeight.Bold)
                        Text("این دست: ${p.lastRoundScore} | مجموع: ${p.totalScore}")
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = {
            if (state.isRoundOver && !state.isGameOver && isHost) {
                Button(onClick = onNextRound) {
                    Text("شروع دست بعدی")
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text("بستن")
                }
            }
        }
    )
}
